const amountButtons = document.querySelectorAll(".amount");
const selectedAmount = document.getElementById("selected-amount");
const donateLink = document.getElementById("donate-link");

amountButtons.forEach((button) => {
  button.addEventListener("click", () => {
    amountButtons.forEach((item) => {
      item.classList.remove("selected");
      item.setAttribute("aria-pressed", "false");
    });

    button.classList.add("selected");
    button.setAttribute("aria-pressed", "true");
    selectedAmount.textContent = `$${button.dataset.amount}`;

    // The amount is displayed for the visitor. The charity: water link is
    // informational; this demo does not submit or process a payment.
    donateLink.setAttribute(
      "aria-label",
      `Continue to charity: water's website after selecting a $${button.dataset.amount} gift`
    );
  });
});
