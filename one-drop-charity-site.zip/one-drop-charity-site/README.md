# One Drop, One Childhood Saved

A responsive, student-created clean-water awareness landing page inspired by the supplied design.

## Brand styling
- Signature Yellow: `#FFC700`
- Teal: `#00A19D`
- Typography: Proxima Nova first, with common sans-serif fallbacks.

**Font note:** Proxima Nova is a licensed font. If you have permission to use its webfont files, place them in `assets/fonts/` and add an `@font-face` declaration in `styles.css`. Otherwise, the site uses an available fallback.

## Run in GitHub Codespaces
1. Create a GitHub repository and upload these files, keeping the `assets` folder.
2. Open the repository in Codespaces.
3. Open `index.html`.
4. For a local preview, open a terminal and run:
   ```bash
   python3 -m http.server 8000
   ```
5. In Codespaces, open the **Ports** tab and open port `8000` in the browser.

## Before publishing
- The donation link currently opens the general charity: water website. Replace it in `index.html` with the exact donation page URL you have verified.
- This is an awareness-page demo, not an official charity: water site, and it does not process payments.
- Update the creator name/date in the footer if needed.
- Check that you have permission to publish the supplied photograph.
